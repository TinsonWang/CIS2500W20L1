Program for CIS2500 Winter 2020 Lab 1 by Tinson Wang (Student ID: 0983887).
Program was originally written and completed using camel case as styling prior to lecture stating that C programs
are to be written in snake case. Subsequent programs for this course will be written in snake case.

+Added functionality (usage of a dot as a period in a line will not terminate the program)